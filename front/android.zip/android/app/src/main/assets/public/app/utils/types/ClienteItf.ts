export interface ClienteItf {
    id: string
    nome: string
    email: string
}
